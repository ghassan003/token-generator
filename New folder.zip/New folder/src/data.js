export const serviceAccount = {
  type: "service_account",
  project_id: "blogapp-fce07",
  private_key_id: "a225ecb5da0e814632c3c591db0564ef0f4b3ba5",
  private_key:
    "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDHfOw5mCoSey3p\nSQxF9Uo6Hzsid+FtSKjMO1vTYgnMw8oeIyE3nZgRpxG0NF/Cl2Mn/F/zMFnGRwIU\n7KapivYIWH70I7pw44Qab5o/QsErrebEnAkU1EvtR8nWg+G1TbSl9osWLq/btGiV\nVtjIqB8ATDo8EOI67I4Y3F9N3UbFVzMZSOBWCwpmCTHU6Q41e10jR/QSW8EVeAqP\n4xjfyNfjKdDNsqd5FLOlsS0WNVdEsXgCJjitli0XwZ/7rmO/2ALFtYGS+XUDgMVj\nD+/9JSwHXPpKj0NEQLmyehi8LN0S88v1ebpKw8F1qLHbPfl1cjz8oht13Ck30jCR\nFpnPw4aLAgMBAAECggEABmqiPogCcm274FEVL/rf1FbE1Cr++UDpDQirv3Tb09ZI\nXgfLPbq39XlmPGGi4uNzsQmRHIVlndcS3hFumu15VHNkQf4UNSVcTm1gjMBc7ka9\nsX1DXYQmnQ8+EsRTMj25ncz8VE5UIcD/zC3q8ylVNfE9vkjcvgB14Z7VAfAoIpjI\n5NZmjDey0UcxV/MbXx1krCJMzjCIsV01HPUKA/FQJsFH3rzt4ujQjYV8YlilrVe2\nQZqfBHnxtOuxjBK/1pQ6JgUX41BKIlaDgEy4e1Pe/qi8uDLx4uN9Xx095AI8MyAC\nFe0naLr0LrLaUMzJjTqa3Ja5686gLKQxf3yiLHLXgQKBgQDoaee3rqMwqyUvMm3g\nmAU5HWNlyVMvlaKf8Nj2FuCFi+AYKlutGg/+MBrdgafItelIOVa0ZhHHCbbIgBQR\nAicnAb+Cd18Wu7AvvKR+8RbiuGhLLuHZyjp2xdfndRx7J5hAAFdwcSLBv7togs6g\nZc1etNLgzHuoA5UGaUVyj4QKUQKBgQDbu5wC7op1Dq86misb24wGsQIS1zNzoxBh\nIPbUdPN7n35Z6TF/fceROo/Dswf3ulUbtUX4AHprDOaYXHpF8x4RabM26/njjDq+\nmUbp/2IK0qGxbFsQW71dU0yTQD96CuhFxZ74Ax43X5PILFbGHTn8+1naqFbKpOR+\nt9TWe2NwGwKBgHF0AWFxJsiDQ0ue2nRgwWv4JKVzeeAos5JQCBlZYZDPjz08sDP4\nHQaAhRzMRhN8ebyAAQtfKB55Z3jIzQLggixQdiRCEXEPfhpPhB1To1BZpM/OuwGN\n7qw8OAEM8jJMSc40XHrPP6BE8D88W5GBIJeyvZ5vM4348a6HhRc/Z72BAoGALteQ\ny6M0iv3FZzXEaNzlvetwKLoNsuIZNMuFMwd3fGwk0GAA+E/FAnW8fhilYy8qw4xi\nTRs0/aszYVmdi1nnmAizdsrZa6PSRh2A25NgwDPk2mDiDNuxw7plQaLZpVe76lvV\npsNrZpyOcYbaPMOwP/kJT67BSdPbDhR8X/jP2u8CgYEAkoL5N3MVvg2eqfxCodRN\n7v+XiqtWP8MTr26zrbJaw12g5hmC6v3zO+Wys2l6EkjN4kgHa9gNrN1w1c+rJuQW\nWij3A2n1csPT1Wtp5EVNXyYn3VjZE69uncwm5fE6G2TxX0a+KsQwcjR/RWYWtCyS\nq8lTNyuQly7GQxis44p1kkQ=\n-----END PRIVATE KEY-----\n",
  client_email: "firebase-adminsdk-ll8p6@blogapp-fce07.iam.gserviceaccount.com",
  client_id: "106622272081236786779",
  auth_uri: "https://accounts.google.com/o/oauth2/auth",
  token_uri: "https://oauth2.googleapis.com/token",
  auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
  client_x509_cert_url:
    "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-ll8p6%40blogapp-fce07.iam.gserviceaccount.com",
  universe_domain: "googleapis.com",
};
